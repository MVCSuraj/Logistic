﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ABC_Logistics.Context
{
    public class ABC_DbContext : DbContext
    {

        public ABC_DbContext(DbContextOptions<ABC_DbContext> options) : base(options)
        {

        }

        public DbSet<User_Authenticaiton> User_Authenticaitons { get; set; }
        public DbSet<shipment> shipments { get; set; }
    }
}
