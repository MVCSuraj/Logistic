﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ABC_Logistics.Context
{
    public class shipment
    {
        [Key]
        public int senderid { get; set; }

        [Required(ErrorMessage = "Enter Name")]
        public string sendername { get; set; }
        [Required(ErrorMessage = "Enter Address")]
        public string recipientAdd { get; set; }
        public string Decription { get; set; }
        public string ShipType { get; set; }
        public bool Expedited { get; set; }
    }
}
