﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.


function deleteGadget(id) {
    url = "/Dashboard?id=" + id + "&handler=delete";
    var deleteFormEl = document.getElementById("confirmDelete");
    deleteFormEl.setAttribute("action", url);
    $("#deleteGadgetModal").modal("show");
}

function closeModal() {
    $("#deleteGadgetModal").modal("hide");
}