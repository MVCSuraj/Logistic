using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ABC_Logistics.Context;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace ABC_Logistics.Pages
{
    public class DashboardModel : PageModel
    {
        private readonly ILogger<DashboardModel> _logger;
        readonly ABC_DbContext _abc_dbcontext;
        public DashboardModel(ILogger<DashboardModel> logger, ABC_DbContext aBC_DbContext)
        {
            _logger = logger;
            _abc_dbcontext = aBC_DbContext;
        }
        [BindProperty]
        public List<shipment> shipmentlist { get; set; }

        public void OnGet()
        {
            shipmentlist = _abc_dbcontext.shipments.ToList();
        }
        public async Task<IActionResult> OnPost(shipment sh)
        {
            shipment shi = new shipment()
            {
                sendername = sh.sendername,
                recipientAdd = sh.recipientAdd,
                Decription = sh.Decription,
                ShipType = sh.ShipType,
                Expedited = sh.Expedited
            };
            _abc_dbcontext.shipments.Add(shi);
            _abc_dbcontext.SaveChanges();
            return RedirectToPage("Dashboard");
        }
        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            var currentdata = await _abc_dbcontext.shipments.FindAsync(id);
            if (currentdata != null)
            {
                _abc_dbcontext.shipments.Remove(currentdata);
                await _abc_dbcontext.SaveChangesAsync();
            }
            return RedirectToPage("Dashboard");

        }
    }
}
