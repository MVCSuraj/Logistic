﻿using ABC_Logistics.Context;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ABC_Logistics.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        readonly ABC_DbContext _abc_dbcontext;
        public IndexModel(ILogger<IndexModel> logger, ABC_DbContext aBC_DbContext)
        {
            _logger = logger;
            _abc_dbcontext = aBC_DbContext;
        }
        public void OnGet()
        {
            //User_Authenticaiton emp = new User_Authenticaiton() { username = "Demo", password = "123", isactive = true, role = "admin" };
            //_abc_dbcontext.User_Authenticaitons.Add(emp);
            //_abc_dbcontext.SaveChanges();
            //var students = _abc_dbcontext.User_Authenticaitons.ToList();
            //Label5.Text = "Data Inserted Successfully";
        }

        [BindProperty]
        public User_Authenticaiton loginData { get; set; }

        public async Task<IActionResult> OnPost()
        {
            if (ModelState.IsValid)
            {
                string UN = loginData.username.ToString();
                string PD = loginData.password.ToString();
                var isvalid = (UN!=null && PD!=null);
                if (!isvalid)
                {
                    ModelState.AddModelError("", "username or password is invalid");
                    return Page();
                }
                var identity = new ClaimsIdentity(CookieAuthenticationDefaults.AuthenticationScheme, ClaimTypes.Name, ClaimTypes.Role);
                identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, loginData.username));
                identity.AddClaim(new Claim(ClaimTypes.Name, loginData.username));
                var principal = new ClaimsPrincipal(identity);
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties { IsPersistent = loginData.isactive });
                return RedirectToPage("Dashboard");
            }
            else
            {
                ModelState.AddModelError("", "username or password is blank");
                return Page();

            }
        }
         

    }
}
