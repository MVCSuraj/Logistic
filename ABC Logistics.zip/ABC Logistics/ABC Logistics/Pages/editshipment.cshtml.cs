using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ABC_Logistics.Context;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace ABC_Logistics.Pages
{
    public class editshipmentModel : PageModel
    {
        private readonly ILogger<DashboardModel> _logger;
        readonly ABC_DbContext _abc_dbcontext;
        public editshipmentModel(ILogger<DashboardModel> logger, ABC_DbContext aBC_DbContext)
        {
            _logger = logger;
            _abc_dbcontext = aBC_DbContext;
        }

        [BindProperty]
        public shipment ships { get; set; }
        public void OnGet(int? id)
        {
            if (id != null)
            {
                var data = (from shipments in _abc_dbcontext.shipments
                            where shipments.senderid == id
                            select shipments).SingleOrDefault();
                ships = data;
            }
        }
        public async Task<IActionResult> OnPost()
        {
            var s = ships;
            if (!ModelState.IsValid)
            {
                _abc_dbcontext.Entry(s).Property(x => x.sendername).IsModified = true;
                _abc_dbcontext.Entry(s).Property(x => x.recipientAdd).IsModified = true;
                _abc_dbcontext.Entry(s).Property(x => x.Decription).IsModified = true;
                _abc_dbcontext.Entry(s).Property(x => x.ShipType).IsModified = true;
                _abc_dbcontext.Entry(s).Property(x => x.Expedited).IsModified = true;

                _abc_dbcontext.SaveChanges();
                return RedirectToPage("Dashboard");                
            }
            return Page();

        }
    }
}
