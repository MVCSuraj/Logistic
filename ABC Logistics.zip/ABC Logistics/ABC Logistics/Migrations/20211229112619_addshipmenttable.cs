﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ABC_Logistics.Migrations
{
    public partial class addshipmenttable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "shipments",
                columns: table => new
                {
                    senderid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    sendername = table.Column<string>(nullable: false),
                    recipientAdd = table.Column<string>(nullable: true),
                    Decription = table.Column<string>(nullable: true),
                    ShipType = table.Column<string>(nullable: true),
                    Expedited = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_shipments", x => x.senderid);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "shipments");
        }
    }
}
