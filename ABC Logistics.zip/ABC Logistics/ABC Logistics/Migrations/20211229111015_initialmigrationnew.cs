﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace ABC_Logistics.Migrations
{
    public partial class initialmigrationnew : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_User_Authenticaitons",
                table: "User_Authenticaitons");

            migrationBuilder.DropColumn(
                name: "userid",
                table: "User_Authenticaitons");

            migrationBuilder.AddColumn<int>(
                name: "user_id",
                table: "User_Authenticaitons",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_User_Authenticaitons",
                table: "User_Authenticaitons",
                column: "user_id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_User_Authenticaitons",
                table: "User_Authenticaitons");

            migrationBuilder.DropColumn(
                name: "user_id",
                table: "User_Authenticaitons");

            migrationBuilder.AddColumn<int>(
                name: "userid",
                table: "User_Authenticaitons",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_User_Authenticaitons",
                table: "User_Authenticaitons",
                column: "userid");
        }
    }
}
